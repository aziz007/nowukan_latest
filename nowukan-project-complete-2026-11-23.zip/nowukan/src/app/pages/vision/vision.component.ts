import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-vision',
  standalone: true,
  imports: [RouterLink],
  template: `
    <section class="page-shell">
      <div class="container journey-layout">
        <div class="journey-copy prose">
          <p class="eyebrow">Vision</p>
          <h1 class="section-title">A World Where Language Development Has No Barriers</h1>

          <p class="sub">
            We envision a world where everyone, regardless of where they live or their financial
            circumstances, has access to affordable, high-quality English language development
            and assessment.
          </p>

          <p>
            We aim to remove the barriers of cost, connectivity and access, giving
            individuals and communities the opportunity to learn, communicate and reach their
            full potential.
          </p>
          <p>
            Through innovation, collaboration and responsible technology, we are making English
            language development and assessment more accessible, inclusive and impactful
            worldwide.
          </p>
          <p>
            Our vision and commitment are also reflected in our ongoing development, <br />
            <span class="ukan-products-inline ukan-products-line"><span class="p-junior">UKan Junior</span><span class="sep" aria-hidden="true"> | </span><span class="p-read">UKan Read</span><span class="sep" aria-hidden="true"> | </span><span class="p-spell">UKan Spell</span><span class="sep" aria-hidden="true"> | </span><span class="p-listen">UKan Listen</span><span class="sep" aria-hidden="true"> | </span><span class="p-talk">UKan Talk</span></span> <br />
            which are already in the development pipeline.
          </p>

          <p class="note"><strong>Breaking barriers. Opening opportunities. Empowering people.</strong></p>

          <div class="btn-row">
            <a routerLink="/collaborate" class="btn btn-benefits">Collaborate With Us</a>
            <a routerLink="/register" class="btn btn-gold">Register Now</a>
            <a routerLink="/buy-now" class="btn btn-primary">Buy Now</a>
          </div>
        </div>

        <div class="journey-visual journey-visual-below-long-title">
          <figure class="people-cutout">
            <img
              src="assets/img/vision-breaking-barriers.webp"
              alt="People walking a golden path through a broken wall towards a connected globe — breaking barriers to English learning worldwide"
              width="1060"
              height="1469"
            />
          </figure>
        </div>
      </div>
    </section>
  `,
})
export class VisionComponent {}
